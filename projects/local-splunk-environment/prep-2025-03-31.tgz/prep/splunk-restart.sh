SPLUNK_HOME=/opt/splunk
$SPLUNK_HOME/bin/splunk restart