target_uri=https://www.splunk.com/en_us/download/splunk-enterprise.html
#target_uri=https://www.splunk.com/en_us/download/universal-forwarder.html
mkdir /tmp/download-splunk
cd /tmp/download-splunk
wget -O downloaded.html $target_uri
filename=`cat downloaded.html | awk -F'data-link="' '{print $2}' | awk -F'"' '{print $1}' | grep linux | grep x86_64 | grep tgz`
echo wget $filename
wget $filename
